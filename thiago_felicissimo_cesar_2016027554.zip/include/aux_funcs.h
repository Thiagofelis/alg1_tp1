#ifndef AUX_FUNCS_H_INCLUDED
#define AUX_FUNCS_H_INCLUDED

int read(FILE* fp, char* buffer);

#endif // AUX_FUNCS_H_INCLUDED
